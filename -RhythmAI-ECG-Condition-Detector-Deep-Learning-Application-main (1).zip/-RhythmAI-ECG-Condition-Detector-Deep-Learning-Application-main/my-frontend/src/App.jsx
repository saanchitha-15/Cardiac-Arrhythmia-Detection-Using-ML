import ECGClassifier from './components/ECGClassifier'
import './App.css'

function App() {
  return <ECGClassifier />
}

export default App